<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{ulogin}prestashop>ulogin_fb8b5e94bbdba3b69dbbe8b45fee0182'] = 'uLogin';
$_MODULE['<{ulogin}prestashop>ulogin_77c06808ca5a7509f2ce1252f08ab8e6'] = 'Social  Authorization in 1 click';
$_MODULE['<{ulogin}prestashop>ulogin_b2034900fc93870f1034cc338c81a495'] = 'Are you sure you want to uninstall uLogin?';
$_MODULE['<{ulogin}prestashop>ulogin_97eb2119bb4033a8a134eba57094c30b'] = 'Oops, there was some warning!';
$_MODULE['<{ulogin}prestashop>ulogin_7a6d00bbb9d68e2947036293a5f15804'] = 'Specify an invalid value';
$_MODULE['<{ulogin}prestashop>ulogin_22d8ff492a13fa906407341fb129ccfc'] = 'Settings saved';
$_MODULE['<{ulogin}prestashop>ulogin_7c1e42fb1481a285e5f0533779193059'] = 'uLogin settings';
$_MODULE['<{ulogin}prestashop>ulogin_0b8f7e6d920bf2758df495879eb5195c'] = 'uLogin ID login form to the navigation bar:';
$_MODULE['<{ulogin}prestashop>ulogin_e33c1d175b1a0153c1c99e39818c6813'] = 'Widget ID for the navigation bar (hook Nav). Empty field - the default widget';
$_MODULE['<{ulogin}prestashop>ulogin_2ba8618243cdb404b394580711bde4b1'] = 'uLogin ID form for comment:';
$_MODULE['<{ulogin}prestashop>ulogin_32944b590414a6b8c90d0debed88d3d5'] = 'Widget ID for comment. Empty field - the default widget';
$_MODULE['<{ulogin}prestashop>ulogin_9da218c4cadef4bf734730edd80649c2'] = 'uLogin ID general form:';
$_MODULE['<{ulogin}prestashop>ulogin_36977e55e05391c85cd08d11b0e7575b'] = 'Widget ID for each hook. Empty field - the default widget';
$_MODULE['<{ulogin}prestashop>ulogin_877edae3177bd1c885f57d0c5e048951'] = 'Txt:';
$_MODULE['<{ulogin}prestashop>ulogin_cdd0dcdbeaee8133b0308ed15eae41aa'] = 'Text type \"Login with:\"';
$_MODULE['<{ulogin}prestashop>ulogin_54e586abc190ffcba6533aabe0929382'] = 'Save a link to the profile:';
$_MODULE['<{ulogin}prestashop>ulogin_6b4c699093510b82403b17fe43ec3a51'] = 'Save a link to a page in the social network user authorization through uLogin';
$_MODULE['<{ulogin}prestashop>ulogin_f2e3f707d57e6441543b167c0e908dcd'] = 'Save Settings';
$_MODULE['<{ulogin}prestashop>ulogin_74ea58b6a801f0dce4e5d34dbca034dc'] = 'Save';
$_MODULE['<{ulogin}prestashop>ulogin_7322a098b5810b2ae08a3eed2370bb6a'] = 'Back to list';
